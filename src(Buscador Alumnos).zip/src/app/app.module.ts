import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { EscuelaService } from './escuela.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    HttpParams
  ],
  providers: [EscuelaService],
  bootstrap: [AppComponent]
})
export class AppModule { }
