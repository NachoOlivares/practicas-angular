import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export class Curso{
  idCurso!:number;
  denominacion!:string;
}
export class Alumno{
  dni!:string;
  nombre!:string;
  email!:string;
}

@Injectable({
  providedIn: 'root'
})
export class EscuelaService {

  //url:string="http://localhost:8080/15-escuela-ajax-angular/";
  constructor(private _http:HttpClient) { }

  cursos(){
    return this._http.get<Curso[]>("ListaCursos");
  }

  alumnosCurso(idCurso:number){
    return this._http.get<Alumno[]>("buscarAlumnos", {params:{"idCurso":idCurso}});
    //Alternativa post
    /*
    let parametros=new HttpParams();
      parametros=parametros.set("idCurso",idCurso);
      let heads=new HttpHeaders();
      heads.set('Content-Type','application/x-www-form-urlencoded');
      return this.http.post<Alumno[]>("buscarAlumnos",parametros,{headers:heads});  */
  }
}
