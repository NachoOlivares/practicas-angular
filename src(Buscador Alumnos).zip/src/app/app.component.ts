import { Component } from '@angular/core';
import { Alumno, Curso, EscuelaService } from './escuela.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'buscadorAlumnos';

  idCurso!:number;
  cursos!:Curso[];
  alumnos!:Alumno[];

  constructor(private service:EscuelaService){
    this.service.cursos().subscribe(data=>this.cursos=data);
  }

  buscar(){
    this.service.alumnosCurso(this.idCurso).subscribe(data=>this.alumnos=data);
  }
}
