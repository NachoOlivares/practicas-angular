export class Juego{

  constructor(
    public nombre:string,
    public genero:string,
    public year:Date
  ){}
}
