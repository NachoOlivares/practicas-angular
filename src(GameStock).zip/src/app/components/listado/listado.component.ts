import { Component, OnInit } from '@angular/core';
import { Juego } from 'src/app/models/Juego.model';
import { RecolectaService } from 'src/app/services/recolecta.service';

@Component({
  selector: 'app-listado',
  templateUrl: './listado.component.html',
  styleUrls: ['./listado.component.css']
})
export class ListadoComponent implements OnInit {

  nombre!:string;
  juegos!:Juego[];
  juego!:Juego;

  constructor(private app:RecolectaService) {
    //We will have this in here to start the application with the list juegos filled
    this.app.ListarJuegos().subscribe(data=>this.juegos=data);
  }

  buscar(){
    this.app.BuscarJuegos(this.nombre).subscribe(data=>this.juego=data);
  }

  ngOnInit(): void {
  }


}
