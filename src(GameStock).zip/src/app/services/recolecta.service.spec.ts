import { TestBed } from '@angular/core/testing';

import { RecolectaService } from './recolecta.service';

describe('RecolectaService', () => {
  let service: RecolectaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RecolectaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
