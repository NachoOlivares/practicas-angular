import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Juego } from '../models/Juego.model';

@Injectable({providedIn: 'root'})
export class ServiceNameService {
  constructor(private httpClient: HttpClient) { }

}

@Injectable({
  providedIn: 'root'
})
export class RecolectaService {

  url:string="http://localhost:8080/GameStock/"
  constructor(private _http:HttpClient) { }

  ListarJuegos(){
    return this._http.get<Juego[]>(this.url+"ListGames");
  }

  CrearJuegos(){
    return this._http.get<Juego>("AddGame");
  }

  BuscarJuegos(nombre:string){
    return this._http.get<Juego>(this.url+"SearchGames", {params:{"nombre":nombre}});
  }

  BuscarJuegosYear(){
    return this._http.get<Juego>("ListGameYear");
  }
}
