import { Component, OnInit } from '@angular/core';
import { Formacion } from '../gateway.service';
import { GatewayService } from '../gateway.service';

@Component({
  selector: 'app-eureka',
  templateUrl: './eureka.component.html',
  styleUrls: ['./eureka.component.css']
})
export class EurekaComponent implements OnInit {

  formaciones: Formacion[] = [];

  constructor(
    private service: GatewayService
  ) { }

  listar() {
    this.service.formaciones().subscribe(data=> this.formaciones = data);
    alert(this.formaciones.length);
  }

  ngOnInit(): void {
    this.listar();
  }

}
