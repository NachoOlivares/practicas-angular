import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';


export class Formacion {
  curso!: string;
  asignatura!: string;
  duracion!: number;
  turno!: number;
}


@Injectable({
  providedIn: 'root'
})
export class GatewayService {

  //ip del gateway, no es la direccion original sino la ip a la que envia el servicio el gateway
  url: string = "http://localhost:10000/sformacion";

  constructor(private _http: HttpClient) { }

  formaciones() {
    /*
    en caso de necesitar credenciales para acceder a la url:
    */
    /*let heads = new HttpHeaders();
    heads.set('Authorization', "basic " + atob("user1:user1"));*/
    return this._http.get<Formacion[]>(this.url+"formaciones"/*, {headers:heads}*/);


    //return this._http.get<Formacion[]>(this.url + "formaciones");
  }
}
