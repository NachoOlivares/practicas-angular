import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NormalizarService {

  constructor() { }

  normalizar(wrd:string){
    return wrd.toLowerCase().replace(/[!.,()]/g, "");
  }
}
