import { Component, OnInit } from '@angular/core';
import { Curso, CursosServiceService } from '../cursos-service.service';

@Component({
  selector: 'app-eliminar',
  templateUrl: './eliminar.component.html',
  styleUrls: ['./eliminar.component.css']
})
export class EliminarComponent implements OnInit {

  cursos!:Curso[];
  denominacion!:string;

  constructor(private service:CursosServiceService){
  }



  eliminar(){
    this.service.eliminarcurso(this.denominacion).subscribe()
  }

  ngOnInit(): void {
    this.service.cursos().subscribe(data=>this.cursos=data);
  }
}
