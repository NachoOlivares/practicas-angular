import { Component, OnInit } from '@angular/core';
import { Curso, CursosServiceService } from '../cursos-service.service';

@Component({
  selector: 'app-buscar-duracion',
  templateUrl: './buscar-duracion.component.html',
  styleUrls: ['./buscar-duracion.component.css']
})
export class BuscarDuracionComponent implements OnInit {

  cursos!:Curso[];
  duracion!:number;

  constructor(private service:CursosServiceService){
  }

  buscarDuracion(){
    this.service.buscarDuracion(this.duracion).subscribe(data=>this.cursos=data);
  }

  ngOnInit(): void {
  }
}
