import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuscarDuracionComponent } from './buscar-duracion.component';

describe('BuscarDuracionComponent', () => {
  let component: BuscarDuracionComponent;
  let fixture: ComponentFixture<BuscarDuracionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuscarDuracionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BuscarDuracionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
