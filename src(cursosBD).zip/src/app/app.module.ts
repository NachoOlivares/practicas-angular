import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AltaComponent } from './alta/alta.component';
import { BusquedaComponent } from './busqueda/busqueda.component';
import { CursosServiceService } from './cursos-service.service';
import { EliminarComponent } from './eliminar/eliminar.component';
import { BuscarDuracionComponent } from './buscar-duracion/buscar-duracion.component';

@NgModule({
  declarations: [
    AppComponent,
    BusquedaComponent,
    AltaComponent,
    EliminarComponent,
    BuscarDuracionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [CursosServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
