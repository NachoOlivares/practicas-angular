import { TestBed } from '@angular/core/testing';

import { NormalizarService } from './normalizar.service';

describe('NormalizarService', () => {
  let service: NormalizarService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NormalizarService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
