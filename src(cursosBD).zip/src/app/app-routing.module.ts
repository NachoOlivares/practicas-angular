import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AltaComponent } from './alta/alta.component';
import { BuscarDuracionComponent } from './buscar-duracion/buscar-duracion.component';
import { BusquedaComponent } from './busqueda/busqueda.component';
import { EliminarComponent } from './eliminar/eliminar.component';

const routes: Routes = [
  {
    path: 'busqueda',
    component: BusquedaComponent
  },
  {
    path: 'alta',
    component: AltaComponent
  },
  {
    path: 'busquedaDuracion',
    component: BuscarDuracionComponent
  },
  {
    path: 'eliminar',
    component: EliminarComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
