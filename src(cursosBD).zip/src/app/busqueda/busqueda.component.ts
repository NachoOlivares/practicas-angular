import { Component, OnInit } from '@angular/core';
import { Curso, CursosServiceService } from '../cursos-service.service';

@Component({
  selector: 'app-busqueda',
  templateUrl: './busqueda.component.html',
  styleUrls: ['./busqueda.component.css']
})
export class BusquedaComponent implements OnInit {
  tematica!: string;
  cursos!: string[];
  tematicas!: Curso[];

  constructor(private service: CursosServiceService) {
  }
  search() {
    this.service.tematicaSet(this.tematica).subscribe(data=>this.tematicas=data);
  }

  ngOnInit(): void {
    this.service.tematicasBuscar().subscribe(data => this.cursos = data);
  }

}
