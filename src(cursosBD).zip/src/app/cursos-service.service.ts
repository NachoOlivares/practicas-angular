import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

export class Curso{
  codigoCurso!:number;
  denominacion!:string;
  duracion!:number;
  tematica!:string;
}

@Injectable({
  providedIn: 'root'
})
export class CursosServiceService {

    url:string="http://localhost:8500/cursos/";
    constructor(private _http:HttpClient) { }

    cursos(){
      return this._http.get<Curso[]>(this.url+"showall");
    }

    tematicasBuscar(){
      return this._http.get<string[]>(this.url+"tematicas");
    }

    alta(curso:Curso){
      return this._http.post<Curso>(this.url+"curso/", curso);
    }

    tematicaSet(tematica:string){
      return this._http.get<Curso[]>(this.url+"cursostematica/"+tematica);
    }

    //Eliminar cursos por denominacion
    eliminarcurso(denominacion:string){
      return this._http.delete<Curso>(this.url+"curso/"+denominacion);
    }

    //Buscar cursos por duracion maxima
    buscarDuracion(duracion:number){
      return this._http.get<Curso[]>(this.url+"cursosduracion/"+duracion);
    }

}
