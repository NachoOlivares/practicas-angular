import { Component, OnInit } from '@angular/core';
import { Curso, CursosServiceService } from '../cursos-service.service';
import { NormalizarService } from '../normalizar.service';

@Component({
  selector: 'app-alta',
  templateUrl: './alta.component.html',
  styleUrls: ['./alta.component.css'],
  providers: [NormalizarService, CursosServiceService]
})
export class AltaComponent implements OnInit {

  cursos: Curso[] = [];
  curso: Curso = new Curso;
  validator: boolean = true;

  constructor(
    private service: CursosServiceService,
    private app: NormalizarService
  ) { }

  alta() {
    this.service.alta(this.curso).subscribe();
    alert("Curso subido con exito!");
  }

  Valid(denominacion: string) {
    for (var i = 0; i < this.cursos.length; i++) {
      if (this.cursos[i].denominacion == denominacion && denominacion != null) {
        this.validator = false;
        break;
      } else {
        this.validator = true;
      }
    }

  }

  ngOnInit(): void {
    this.service.cursos().subscribe(data => this.cursos = data);
  }
}
